# Scribble Fighters — four milestone snapshots

Each numbered folder is a complete independent Godot project from the requested milestone's first commit. Later fixes and polish are deliberately not backported. Original source, assets, license files, and documentation are preserved exactly as committed.

| Folder | Commit | Milestone |
| --- | --- | --- |
| 01-first-coded-prototype | 6a6b20b | First code-drawn playable prototype |
| 02-kenney-assets | ff93042 | First Kenney art integration |
| 03-sounds-and-countdown | 732e9e1 | First battle sounds and voiced countdown |
| 04-main-menu | 7bd3dac | First main menu, difficulty, and saved settings |

## Open a version

1. Extract this ZIP completely.
2. Open Godot 4.6's Project Manager and choose Import.
3. Select project.godot inside the desired numbered folder.
4. Allow resource import and press F5.

Do not combine folders or copy source files between them. The early versions start directly in the arena; the fourth starts in its original main menu. No .git history, generated .godot caches, user settings, or cloud runtime files are included. Godot rebuilds its cache when importing.

The versions share the original application name, so Godot may reuse the same user-data location when trying them on one computer. For isolated saved settings during comparisons, use a different XDG_DATA_HOME on Linux or change each copied project's application name in Godot Project Settings. Preserve the provided original snapshots when making modifications.

VERSION_INFO.txt in each folder records its full SHA. VERSIONS.json provides a machine-readable index. This package contains the four requested historical milestones, not the final current version.
